import datetime
import pyttsx3

def greet():
    engine = pyttsx3.init()
    hour = datetime.datetime.now().hour

    if 5 <= hour < 12:
        msg = "Good morning! I hope your day starts strong."
    elif 12 <= hour < 18:
        msg = "Good afternoon! Let’s keep up the momentum."
    elif 18 <= hour < 23:
        msg = "Good evening! Let’s wrap up the day wisely."
    else:
        msg = "It's late night. Consider some rest soon."

    print("🤖", msg)
    engine.say(msg)
    engine.runAndWait()

if __name__ == "__main__":
    greet()
